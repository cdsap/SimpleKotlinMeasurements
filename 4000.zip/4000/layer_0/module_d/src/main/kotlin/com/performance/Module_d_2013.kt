package com.performance

class Module_d_2013 {
   fun alo() {
     println("module_d")
     
     }
}